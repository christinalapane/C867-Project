//
//  degree.h
//  C867_TASK.cpp
//
//  Created by Christina LaPane on 10/30/21.
//

#ifndef degree_h
#define degree_h
#include <string>

//Question C 
enum DegreeProgram{SECURITY, NETWORK, SOFTWARE};


//array parallel to enum that displays string//
static const std::string degreeProgramStrings[] = {"SECURITY", "NETWORK","SOFTWARE"};

#endif /* degree_h */
